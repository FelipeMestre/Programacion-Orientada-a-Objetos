
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Parcial {

    public static void main(String[] args) {

        // instanciar curso BasicoIng...
        Conjunto<Alumno> BasicoIng = new Conjunto<>();
        

        // cargar alumnos del curso BasicoIng desde el archivo “basico-ing.txt”
        try{
            FileReader fr;
            fr = new FileReader("src/basico-ing.txt");
            BufferedReader br = new BufferedReader(fr);
            String lineaActual = br.readLine();
            while(lineaActual != null){
                
                String[] splitedLine = lineaActual.split(",");
                
                Integer id = Integer.parseInt(splitedLine[0].trim());
                String nombre = splitedLine[1];
                
                Alumno alumno = new Alumno(id,nombre);
                
                Nodo<Alumno> nodoAlumno = new Nodo<>(id,alumno);
                BasicoIng.insertar(nodoAlumno);
                
                lineaActual = br.readLine();
            }
            br.close();
            fr.close();
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        
        
        // instanciar curso BasicoEmp...
        Conjunto<Alumno> BasicoEmp = new Conjunto<>();
        
        
        // cargar alumnos del curso BasicoEmp desde el archivo “basico-emp.txt”
        try{    
            FileReader fr2;    
            fr2 = new FileReader("src/basico-emp.txt");
            BufferedReader br2 = new BufferedReader(fr2);
            String lineaActual2 = br2.readLine();
            while(lineaActual2 != null){
                
                String[] splitedLine2 = lineaActual2.split(",");
                
                Integer id2 = Integer.parseInt(splitedLine2[0]);
                String nombre2 = splitedLine2[1];
                
                Alumno alumno2 = new Alumno(id2,nombre2);
                
                Nodo<Alumno> nodoAlumno2 = new Nodo<>(id2,alumno2);
                BasicoEmp.insertar(nodoAlumno2);
                
                lineaActual2 = br2.readLine();
            }
            br2.close();
            fr2.close();
        } catch ( IOException ex2){
            System.out.println(ex2.getMessage());
        }
        
        
        // generar el curso "integrador101" con los alumnos que están en condiciones de cursarlo
        Conjunto integrador101 = BasicoEmp.union(BasicoIng);
        

        // guardar en un archivo "integrador101.txt"  - IDEALMENTE ordenados por código de alumno -
        try {    
            BufferedWriter writerUnion = new BufferedWriter(new FileWriter
                                    ("src/integrador101.txt"));
            Nodo<Alumno> escribirEnArchivo = integrador101.getPrimero();

            while (escribirEnArchivo != null){

                writerUnion.write(escribirEnArchivo.getEtiqueta() + "," +escribirEnArchivo.getDato().
                                                                                                getNombre());
                writerUnion.newLine();

                escribirEnArchivo = escribirEnArchivo.getSiguiente();
            }
            writerUnion.close();
        } catch (IOException ex3) {
            System.out.println(ex3.getMessage());
        }
        
        
        // generar el curso "exigente102" con los alumnos que están en condiciones de cursarlo
        Conjunto exigente102 = BasicoEmp.interseccion(BasicoIng);
        
        // guardar en un archivo "exigente102.txt" - IDEALMENTE ordenados por código de alumno -
        
        try {
            BufferedWriter writerInterseccion = new BufferedWriter(new FileWriter(("src/integrador102.txt")));
        
            Nodo<Alumno> alumno102 = exigente102.getPrimero();
        
            while (alumno102 != null){

                writerInterseccion.write(alumno102.getEtiqueta() + "," + alumno102.getDato().getNombre());
                writerInterseccion.newLine();

                alumno102 = alumno102.getSiguiente();

            }
            writerInterseccion.close();
        } catch (IOException ex4){
            System.out.println(ex4.getMessage());
        }
    }

}
