/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ernesto
 * @param <T>
 */
public class ListaOrdenada<T> extends Lista<T> {

    @Override
    public void insertar(Nodo<T> unNodo) {
        if(esVacia()){
            this.setPrimero(unNodo);
        } 
        else{
            Nodo<T> aux = this.getPrimero();
            if(unNodo.getEtiqueta().compareTo(aux.getEtiqueta()) > 0){
                while(aux.getSiguiente() != null){
                    if(unNodo.getEtiqueta().compareTo(aux.getSiguiente().getEtiqueta()) < 0 ){
                        unNodo.setSiguiente(aux.getSiguiente());
                        aux.setSiguiente(unNodo);
                        break;
                    }
                    else{
                        aux = aux.getSiguiente();
                    }
                }
                aux.setSiguiente(unNodo);
            }
            else{
                this.setPrimero(unNodo);
                this.getPrimero().setSiguiente(aux);
            }
        }  
        
    }
}