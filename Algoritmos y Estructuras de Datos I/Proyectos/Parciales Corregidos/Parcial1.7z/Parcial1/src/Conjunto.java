/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ernesto
 * @param <T>
 */
public class Conjunto<T> extends ListaOrdenada<T> implements IConjunto {
// MEJOR: public class Conjunto<T> extends ListaOrdenada<T> implements IConjunto {
    
    @Override
    public Conjunto union(Conjunto otroConjunto) {
        Conjunto<T> conjuntoRetorna = new Conjunto<>();
        Nodo<T> primerNodo = this.getPrimero();
        Nodo<T> segundoNodo = otroConjunto.getPrimero();
        
        while(primerNodo != null){
            if(conjuntoRetorna.buscar(primerNodo.getEtiqueta()) ==  null){
                conjuntoRetorna.insertar(primerNodo.clonar());
            }
            primerNodo = primerNodo.getSiguiente();
        }
        
        while(segundoNodo != null){
            if(conjuntoRetorna.buscar(segundoNodo.getEtiqueta()) == null){
                conjuntoRetorna.insertar(segundoNodo.clonar());
            }
            segundoNodo = segundoNodo.getSiguiente();
        }
        return conjuntoRetorna;
    }

    @Override
    public Conjunto interseccion(Conjunto otroConjunto) {
        
        Conjunto<T> conjuntoRetorna = new Conjunto<>();
        Nodo<T> segundoNodo = otroConjunto.getPrimero();
        
        Nodo<T> primerNodo = this.getPrimero();
        
        while(primerNodo != null){
            
            if (otroConjunto.buscar(primerNodo.getEtiqueta()) != null) {
                
                if (conjuntoRetorna.buscar(primerNodo.getEtiqueta()) == null) {
                        conjuntoRetorna.insertar(primerNodo.clonar());
                }
                
            }
            primerNodo = primerNodo.getSiguiente();
        }
        return conjuntoRetorna; 
    }

    
}
