/*
 * Equipo/:
   Felipe Mestre
   Rodolfo Solaro
   Federico Cabezas
   Guillermo Vogel
 */
package TA3;

import java.io.*;
import static java.lang.Character.isLetter;

/**
 *
 * @author Equipo 7
 */
public class ContadorPalabras {
    
    public int contarPalabras(String frase){
        
        boolean contar = true;
        
        int palabras = 0;
        
        for (int i = 0; i < frase.length(); i++){
            
            if (frase.charAt(i) == ' '){
                contar = true;
            }
            
            else if (contar) {
                    palabras ++;
                    contar = false;
            }
        }
        return palabras;
    }   
    public int contarVocales (String frase){
        
        int vocales = 0;
        
        for (int i = 0; i < frase.length(); i++){
            
            switch (frase.charAt(i)){
                case 'a' : 
                case 'e' :
                case 'i' :
                case 'o' :
                case 'u' : {
                    vocales ++;
                    break;
                }
            }
        }
        return vocales;
    }
    
    public int contarConsonantes (String frase){
        
        int letras = 0;
        
        for (int i = 0; i < frase.length(); i++){
            if (isLetter(frase.charAt(i))){
                
                letras ++;
            
            }
        }
        return letras-this.contarVocales(frase);
    }
    
    public int palabrasMayoresA(int x, String palabra){ //a aa aaa aaaa
        Boolean espacio = false;
        int ContadorPalabras = 0;
        int LargoPalabra=0;
        for (int i = 0 ;i< palabra.length() ; i++ ) {
            if (palabra.charAt(i) == ' ' ){
                espacio = true;
                if(LargoPalabra > x){                    
                    ContadorPalabras++; 
                }        
                LargoPalabra =0;
            }else if (palabra.charAt(i) != ' '  ){
                LargoPalabra++;    
                espacio = false;
                if (i == palabra.length()-1){
                  if(LargoPalabra > x){                    
                        ContadorPalabras++; 
                    }   
                }
            }            
        }
        return ContadorPalabras ;
    }
    
    public String[] obtenerLineas(String ruta) throws FileNotFoundException, IOException{
        FileReader reader = new FileReader(ruta);    
        BufferedReader buffer = new BufferedReader(reader);         
        int lineas = (int) buffer.lines().count() ;
        System.out.println(lineas);
        reader = new FileReader(ruta);  
        buffer=new BufferedReader(reader);
        String[] stringPalabras = new String[lineas];
        int i=0;    
        String linea = buffer.readLine();
        while( linea != null ){ 
            stringPalabras[i] = linea;
            linea = buffer.readLine(); 
            i++;
          }  
        buffer.close();    
        reader.close();   
        return stringPalabras;
    }
    
    public int cantidadPalabras(String[] lineasArchivo){
        
        int totalPalabras = 0;
        
        for (int i = 0; i < lineasArchivo.length; i++){
            
            totalPalabras += this.contarPalabras(lineasArchivo[i]);
        }
        
        return totalPalabras;
    }
    
    public int cantidadVocales(String[] lineasArchivo){
        int totalVocales = 0;
        
        for (int i = 0; i < lineasArchivo.length; i++){
            
            totalVocales += this.contarVocales(lineasArchivo[i]);
        }
        
        return totalVocales;
    }
    
    public int cantidadConsonantes(String[] lineasArchivo){
        int totalConsonantes = 0;
        
        for (int i = 0; i < lineasArchivo.length; i++){
            
            totalConsonantes += this.contarConsonantes(lineasArchivo[i]);
        }
        
        return totalConsonantes;
    }
    
    public int cantidadPalabrasMayoresA(int largo, String[] lineasArchivo){
        int palabras = 0;
        
        for (int i = 0; i < lineasArchivo.length; i++){
            
            palabras += this.palabrasMayoresA(largo,lineasArchivo[i]);
        }
        
        return palabras;
    }
    
    
 
    public static void main (String[] args) throws FileNotFoundException, IOException {
        
        ContadorPalabras cp = new ContadorPalabras();
        
        String[] lineas = cp.obtenerLineas("src/TA3/UT2_TA1_ARCHIVO_EJEMPLO.txt");
        
        
        int consonantes = cp.cantidadConsonantes(lineas);                
        int vocales = cp.cantidadVocales(lineas);        
        int palabras = cp.cantidadPalabras(lineas);
        int palabrasMayores = cp.cantidadPalabrasMayoresA(4,lineas);
        
        System.out.println("Cantidad de lineas: " + lineas.length);
        System.out.println("Consonantes: " + consonantes);
        System.out.println("Vocales: " + vocales);        
        System.out.println("Palabras: " + palabras);
        System.out.println("Palabras mayores a 4 letras: " + palabrasMayores);
        
        for(int i = 0; i < lineas.length; i++){
            System.out.println(lineas[i]);
        }
        
        
    }
}
 